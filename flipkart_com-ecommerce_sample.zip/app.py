from flask import Flask, request, jsonify, render_template
import pickle
import numpy as np

# Initialize Flask app
app = Flask(__name__)

# Load the trained model and pre-fitted scaler
model_path = "model.pkl"
scaler_path = "scaler.pkl"  # Load the pre-fitted scaler
model = pickle.load(open(model_path, "rb"))
scaler = pickle.load(open(scaler_path, "rb"))  # Load the fitted scaler

# Mock dataset for demonstration purposes
dataset = [
    {"uniq_id": "1", "product_name": "Product A", "retail_price": 100, "discounted_price": 80, "brand": "Brand X"},
    {"uniq_id": "2", "product_name": "Product B", "retail_price": 200, "discounted_price": 150, "brand": "Brand Y"},
    {"uniq_id": "3", "product_name": "Product C", "retail_price": 300, "discounted_price": 250, "brand": "Brand Z"},
]

# Define home route
@app.route("/")
def home():
    return render_template("index.html")  # Ensure index.html is in the 'templates' directory

# Define predict route
@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Get JSON data from request
        data = request.get_json()
        retail_price = data.get("retail_price", None)
        discounted_price = data.get("discounted_price", None)

        # Validate input
        if retail_price is None or discounted_price is None:
            return jsonify({"error": "Both 'retail_price' and 'discounted_price' must be provided"}), 400

        # Preprocess input data
        input_data = np.array([[retail_price, discounted_price]])
        input_data_scaled = scaler.transform(input_data)  # Use the pre-fitted scaler

        # Predict using the model
        prediction = model.predict(input_data_scaled)

        # Return prediction
        return jsonify({"prediction": prediction[0]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Define dataset route
@app.route("/dataset", methods=["GET"])
def get_dataset():
    try:
        # Return dataset in JSON format
        return jsonify(dataset)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Run Flask app
if __name__ == "__main__":
    app.run(debug=True)
