from sklearn.preprocessing import StandardScaler
import pickle
import numpy as np

# Example of training data (replace with actual training data)
training_data = np.array([[100, 80], [200, 150], [300, 250]])  # Example dataset

# Initialize StandardScaler and fit it on the training data
scaler = StandardScaler()
scaler.fit(training_data)

# Save the scaler using pickle
pickle.dump(scaler, open("scaler.pkl", "wb"))
